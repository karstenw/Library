#!/bin/bash

python css3colors_test.py
python geom_test.py
python parseconfig_test.py
python evalexpr_test.py
python cairowrapper_test.py

