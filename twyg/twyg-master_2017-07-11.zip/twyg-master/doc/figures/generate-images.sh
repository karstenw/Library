#!/bin/bash
find ./ -name '*.py' -exec python '{}' \; -print
