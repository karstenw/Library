.. _properties-reference:

Properties reference
====================

.. toctree::
   :maxdepth: 3

   layout
   nodes
   connections
   colors


