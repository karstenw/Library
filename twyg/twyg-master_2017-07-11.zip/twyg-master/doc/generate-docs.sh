#!/bin/bash

make clean dirhtml_all
