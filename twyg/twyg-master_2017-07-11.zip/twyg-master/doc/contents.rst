.. toctree::
   :maxdepth: 2
   :hidden:

   docs/index
