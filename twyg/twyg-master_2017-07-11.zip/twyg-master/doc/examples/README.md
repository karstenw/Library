Examples
========

To generate all the examples on the project website, execute
``generate-samples.py``. ``twyg`` has to be installed for the script to work
correctly. Edit the script if you want only PDF, PNG or SVG output.
